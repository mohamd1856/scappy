from scapy.all import *

# rdpcap is a function that reads a cap file and returns a packet list
packets=rdpcap('CaptureFile.cap')

############################### Q8 ########################################
print([i+1 for i in range(len(packets)) if DNS in packets[i]])

############################### Q9 ########################################
print([i+1 for i in range(len(packets)) if DNS in packets[i] and packets[i][DNS].an is None])

############################### Q10 ########################################
print([packets[i][DNS].qd.qname for i in range(len(packets)) if DNS in packets[i] and packets[i][DNS].an is None])
