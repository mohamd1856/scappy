from scapy.all import *

# rdpcap is a function that reads a cap file and returns a packet list
packets=rdpcap('CaptureFile.cap')
print(type(packets))                # -> <class 'scapy.plist.PacketList'>

############################### Q1 ########################################
first_packet=packets[0]
print(type(first_packet))           # -> <class 'scapy.layers.l2.Ether'>
print(len(first_packet))            # -> 84

############################### Q2 ########################################
counters={
    'google':0,
    'ynet':0,
    'SuperPhramLogo.gif':0,
    'HelloWorld':0
}

for pkt in packets:
    for key in counters.keys():
        counters[key]+=0 if str(pkt).count(key)==0 else 1

print(counters)                     # -> {'google': 265, 'ynet': 318, 'SuperPhramLogo.gif': 0, 'HelloWorld': 0}

############################### Q3 ########################################
print(packets)                      # -> <CaptureFile.cap: TCP:998 UDP:112 ICMP:0 Other:5>
print(len(packets))                 # ->  1115  

############################### Q4 ########################################
pkt_len,pkt_indx=max([(len(packets[i]),i+1) for i in range(len(packets))])
print("pkt_len=",pkt_len,"pkt_indx=",pkt_indx)  # -> pkt_len= 1514 pkt_indx= 1053

############################### Q5 ########################################
pkt_len,pkt_indx=min([(len(packets[i]),i+1) for i in range(len(packets))])
print("pkt_len=",pkt_len,"pkt_indx=",pkt_indx)  # -> pkt_len= 42 pkt_indx= 471

############################### Q6 ########################################
get_packets=[str(p).split("Host: ")[1].split("\\r\\n")[0] for p in packets if str(p).count("GET")>0]
print(get_packets)

