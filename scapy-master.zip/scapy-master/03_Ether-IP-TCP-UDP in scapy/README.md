# Protocols by layers
* TCP and UDP - layer 4 - where ports matter
* IP - layer 3 - main headers are the source and the destination
* Ethernet (and wifi) - layer 2 - main headers are dest and src addresses called MAC addresses



#### with scapy, we can check all the headers (properties) of Ether:
```
>>> ls(Ether())
WARNING: Mac address to reach destination not found. Using broadcast.
dst        : DestMACField                        = 'ff:ff:ff:ff:ff:ff' (None)
src        : SourceMACField                      = 'e4:70:b8:4b:f2:f3' (None)
type       : XShortEnumField                     = 36864           (36864)
```

#### with scapy, we can check all headers (properties) of IP:
```
>>> ls(IP())
version    : BitField (4 bits)                   = 4               (4)
ihl        : BitField (4 bits)                   = None            (None)
tos        : XByteField                          = 0               (0)
len        : ShortField                          = None            (None)
id         : ShortField                          = 1               (1)
flags      : FlagsField (3 bits)                 = <Flag 0 ()>     (<Flag 0 ()>)
frag       : BitField (13 bits)                  = 0               (0)
ttl        : ByteField                           = 64              (64)
proto      : ByteEnumField                       = 0               (0)
chksum     : XShortField                         = None            (None)
src        : SourceIPField                       = '127.0.0.1'     (None)
dst        : DestIPField                         = '127.0.0.1'     (None)
options    : PacketListField                     = []              ([])
```

#### with scapy, we can check all the headers (properties) of UDP:
```
>>> ls(UDP())
sport      : ShortEnumField                      = 53              (53)
dport      : ShortEnumField                      = 53              (53)
len        : ShortField                          = None            (None)
chksum     : XShortField                         = None            (None)
```

#### with scapy, we can check all the headers (properties) of TCP:
```
ls(TCP())
sport      : ShortEnumField                      = 20              (20)
dport      : ShortEnumField                      = 80              (80)
seq        : IntField                            = 0               (0)
ack        : IntField                            = 0               (0)
dataofs    : BitField (4 bits)                   = None            (None)
reserved   : BitField (3 bits)                   = 0               (0)
flags      : FlagsField (9 bits)                 = <Flag 2 (S)>    (<Flag 2 (S)>)
window     : ShortField                          = 8192            (8192)
chksum     : XShortField                         = None            (None)
urgptr     : ShortField                          = 0               (0)
options    : TCPOptionsField                     = []              (b'')
```
