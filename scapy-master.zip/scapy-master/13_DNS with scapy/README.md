# Steps to sniff and send dns packet:
* In scapy run:
```
a=sniff(5,filter="udp port 53")
```
or:
```
a=sniff(5,lfilter=lambda p:DNS in p)
```
* In another shell run:
```
anna@HP-Printer:~$ dig canada.com
```
* Go back to scapy shell and run:
```
>>> a.summary()
Ether / IP / UDP / DNS Qry "b'_raop._tcp.local.'" 
Ether / IP / UDP / DNS Qry "b'canada.com.'" 
Ether / IP / UDP / DNS Ans "199.71.40.135" 
Ether / IP / UDP / DNS Qry "b'_raop._tcp.local.'" 
Ether / IP / UDP / DNS Qry "b'_raop._tcp.local.'" 
>>> a[1].show()
###[ Ethernet ]### 
  dst= d4:7b:b0:79:53:31
  src= d4:6a:6a:ab:3e:b3
  type= IPv4
###[ IP ]### 
     version= 4
     ihl= 5
     tos= 0x0
     len= 67
     id= 42290
     flags= DF
     frag= 0
     ttl= 64
     proto= udp
     chksum= 0xb5cc
     src= 192.168.1.13
     dst= 185.180.100.65
     \options\
###[ UDP ]### 
        sport= 57814
        dport= domain
        len= 47
        chksum= 0xdfeb
###[ DNS ]### 
           id= 30715
           qr= 0
           opcode= QUERY
           aa= 0
           tc= 0
           rd= 1
           ra= 0
           z= 0
           ad= 0
           cd= 0
           rcode= ok
           qdcount= 1
           ancount= 0
           nscount= 0
           arcount= 1
           \qd\
            |###[ DNS Question Record ]### 
            |  qname= 'canada.com.'
            |  qtype= A
            |  qclass= IN
           an= None
           ns= None
           \ar\
            |###[ DNS OPT Resource Record ]### 
            |  rrname= '.'
            |  type= OPT
            |  rclass= 512
            |  extrcode= 0
            |  version= 0
            |  z= 0
            |  rdlen= None
            |  \rdata\

>>> a[2].show()
###[ Ethernet ]### 
  dst= d4:6a:6a:ab:3e:b3
  src= d4:7b:b0:79:53:31
  type= IPv4
###[ IP ]### 
     version= 4
     ihl= 5
     tos= 0x0
     len= 83
     id= 23844
     flags= 
     frag= 0
     ttl= 60
     proto= udp
     chksum= 0x41cb
     src= 185.180.100.65
     dst= 192.168.1.13
     \options\
###[ UDP ]### 
        sport= domain
        dport= 57814
        len= 63
        chksum= 0x6f71
###[ DNS ]### 
           id= 30715
           qr= 1
           opcode= QUERY
           aa= 0
           tc= 0
           rd= 1
           ra= 1
           z= 0
           ad= 0
           cd= 0
           rcode= ok
           qdcount= 1
           ancount= 1
           nscount= 0
           arcount= 1
           \qd\
            |###[ DNS Question Record ]### 
            |  qname= 'canada.com.'
            |  qtype= A
            |  qclass= IN
           \an\
            |###[ DNS Resource Record ]### 
            |  rrname= 'canada.com.'
            |  type= A
            |  rclass= IN
            |  ttl= 300
            |  rdlen= None
            |  rdata= 199.71.40.135
           ns= None
           \ar\
            |###[ DNS OPT Resource Record ]### 
            |  rrname= '.'
            |  type= OPT
            |  rclass= 4096
            |  extrcode= 0
            |  version= 0
            |  z= 0
            |  rdlen= None
            |  \rdata\
```
* Note: ports `53` is the default for the `domain`
```
answer = sr1(IP(dst="1.1.1.1")/UDP(dport=53)/DNS(rd=1,qd=DNSQR(qname="www.ynet.co.il")),verbose=0)

answer.show()
###[ IP ]### 
  version= 4
  ihl= 5
  tos= 0x28
  len= 150
  id= 3830
  flags= DF
  frag= 0
  ttl= 56
  proto= udp
  chksum= 0x26ce
  src= 1.1.1.1
  dst= 10.0.0.106
  \options\
###[ UDP ]### 
     sport= domain
     dport= domain
     len= 130
     chksum= 0x70ee
###[ DNS ]### 
        id= 0
        qr= 1
        opcode= QUERY
        aa= 0
        tc= 0
        rd= 1
        ra= 1
        z= 0
        ad= 0
        cd= 0
        rcode= ok
        qdcount= 1
        ancount= 3
        nscount= 0
        arcount= 0
        \qd\
         |###[ DNS Question Record ]### 
         |  qname= 'www.ynet.co.il.'
         |  qtype= A
         |  qclass= IN
        \an\
         |###[ DNS Resource Record ]### 
         |  rrname= 'www.ynet.co.il.'
         |  type= CNAME
         |  rclass= IN
         |  ttl= 110
         |  rdlen= 28
         |  rdata= 'www.ynet.co.il.edgekey.net.'
         |###[ DNS Resource Record ]### 
         |  rrname= 'www.ynet.co.il.edgekey.net.'
         |  type= CNAME
         |  rclass= IN
         |  ttl= 8473
         |  rdlen= 25
         |  rdata= 'e12476.b.akamaiedge.net.'
         |###[ DNS Resource Record ]### 
         |  rrname= 'e12476.b.akamaiedge.net.'
         |  type= A
         |  rclass= IN
         |  ttl= 10
         |  rdlen= 4
         |  rdata= '2.18.235.16'
        ns= None
        ar= None
```




